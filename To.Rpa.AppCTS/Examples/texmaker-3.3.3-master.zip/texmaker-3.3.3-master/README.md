texmaker-3.3.3
==============

A repo to fix some of Texmakers Bugs